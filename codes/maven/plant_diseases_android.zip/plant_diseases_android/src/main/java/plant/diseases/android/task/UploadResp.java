package plant.diseases.android.task;

/**
 * Created by Administrator on 2014-05-26.
 */
public class UploadResp {

	private boolean result;

	public UploadResp(boolean result) {
		this.result = result;
	}

	public boolean isResult() {
		return result;
	}
}
