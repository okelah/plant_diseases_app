package plant.diseases.android.task;

/**
 * Created by Timothy on 2014/5/24.
 */
public interface IComplete<Param> {

	public void onComplete(Param param);
}
